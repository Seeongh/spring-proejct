package com.example.bioproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BioProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
